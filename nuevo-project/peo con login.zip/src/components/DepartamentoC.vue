<template>
  <div class="about">
    <h1>Departamento C</h1>
  </div>
</template>
