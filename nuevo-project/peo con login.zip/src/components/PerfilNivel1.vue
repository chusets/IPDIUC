<template>
 
 
    <v-container >
     <v-row>
      <v-col cols="5" inset>
         <v-card-text><p class="text-lg-right"> Nivel</p>  </v-card-text>
      </v-col>
      <v-col cols="2">
        <v-text-field inset
            value="Nivel 1"
            solo-inverted
            disabled
          ></v-text-field>
      </v-col>
    </v-row>

    <v-row>
       <v-col cols="5" inset>
         <v-card-text><p class="text-lg-right"> Nombre de Usuario</p>  </v-card-text>
      </v-col>
      <v-col cols="4">
        <v-text-field inset
            value="Nombre de Usuario"
            solo-inverted
            disabled
          ></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="5" inset>
         <v-card-text><p class="text-lg-right"> Departamento</p>  </v-card-text>
      </v-col>
      <v-col cols="4">
        <v-text-field inset
            value="Departamento"
            solo-inverted
            disabled
          ></v-text-field>
      </v-col>
    </v-row>

    <v-row>
       <v-col cols="5" inset>
         <v-card-text><p class="text-lg-right"> Correo</p>  </v-card-text>
      </v-col>
      <v-col cols="4">
        <v-text-field 
            :rules="[rules.required, rules.email]"
            inset
            value="correo@correo.com"
            clearable
            solo-inverted
          ></v-text-field>
      </v-col>
    </v-row>

    <v-row>
       <v-col cols="5" inset>
         <v-card-text><p class="text-lg-right"> Password</p>  </v-card-text>
      </v-col>
      <v-col cols="4">
       <v-text-field
            v-model="password"
            :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
            :rules="[rules.required, rules.min]"
            :type="show1 ? 'text' : 'password'"
            name="input-10-1"
                counter
            @click:append="show1 = !show1"
            solo-inverted
          ></v-text-field>

        

      </v-col>
    </v-row>
    <div class="text-center" >
        <loading :active.sync="isLoading" 
        color="Indigo"
        :can-cancel="true" 
        :on-cancel="onCancel"
        :is-full-page="fullPage"></loading>
               
        
        <v-btn
        color="indigo"
         @click.prevent="doAjax"> <span class="white--text">Guardar</span>
        </v-btn>
   
    </div>


                     
  </v-container>

</template>

<script>
  export default {
    name: "PerfilNivel1"
    
  }
</script>


<script>

    // Import component
    import Loading from 'vue-loading-overlay';
    // Import stylesheet
    import 'vue-loading-overlay/dist/vue-loading.css';

  export default {
    data () {
      return {
        show1: false,
        password: '',
        isLoading: false,
        fullPage: true,
         rules: {
          required: value => !!value || 'Requerido',
          min: v => v.length >= 8 || 'Minimo 8 caracteres',
          counter: value => value.length <= 30 || 'Maximo 20 caracteres',
          email: value => {
            const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            return pattern.test(value) || 'Email Invalido.'
          }
         },
      }
    }, components: {
            Loading
        },
        methods: {
            doAjax() {
                this.isLoading = true;
                // simulate AJAX
                setTimeout(() => {
                  this.isLoading = false
                },5000)
            },
            onCancel() {
              console.log('User cancelled the loader.')
            }
        
        }
    }
  
</script>



