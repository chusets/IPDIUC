<template>
  <div class="about">
    <h1>Preguntas</h1>
  </div>
</template>
