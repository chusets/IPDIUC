<template>
  <div class="about">
    <h1>Eepartamento B</h1>
  </div>
</template>
