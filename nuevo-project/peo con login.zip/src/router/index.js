import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import PerfilNivel1 from "@/components/PerfilNivel1.vue";
import DepartamentoA from "@/components/DepartamentoA.vue";
import DepartamentoB from "@/components/DepartamentoB.vue";
import DepartamentoC from "@/components/DepartamentoC.vue";
import ManualesyGuias from "@/components/ManualesyGuias.vue";
import NormasdeLaInstitucion from "@/components/NormasdeLaInstitucion.vue";
import PreguntasRespuestasExistentes from "@/components/PreguntasRespuestasExistentes.vue";
import PreguntasAbiertas from "@/components/PreguntasAbiertas.vue";
import PreguntasRealizadas from "@/components/PreguntasRealizadas.vue";
import Registro from "@/components/Registro.vue";








Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  
  {
    path: '/PerfilNivel1',
    name: 'PerfilNivel1',
    component: PerfilNivel1
  },
  {
    path: '/Registro',
    name: 'Registro',
    component: Registro
  },
  {
    path: '/PreguntasAbiertas',
    name: 'PreguntasAbiertas',
    component: PreguntasAbiertas
  },
  {
    path: '/DepartamentoA',
    name: 'DepartamentoA',
    component: DepartamentoA
  },
  {
    path: '/DepartamentoB',
    name: 'DepartamentoB',
    component: DepartamentoB
  },
  {
    path: '/DepartamentoC',
    name: 'DepartamentoC',
    component: DepartamentoC
  },
  {
    path: '/ManualesyGuias',
    name: 'ManualesyGuias',
    component: ManualesyGuias
  },
  {
    path: '/NormasdeLaInstitucion',
    name: 'NormasdeLaInstitucion',
    component: NormasdeLaInstitucion
  },
  {
    path: '/PreguntasRespuestasExistentes',
    name: 'PreguntasRespuestasExistentes',
    component: PreguntasRespuestasExistentes
  },
  {
    path: '/PreguntasRealizadas',
    name: 'PreguntasRealizadas',
    component: PreguntasRealizadas
  }

  
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
